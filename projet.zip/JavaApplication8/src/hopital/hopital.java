/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hopital;
import java.io.IOException;
import java.net.URISyntaxException;

/**
 * Class hopital : Class principal avec le main de l'application
 * @author youenlecloirec
 */
public class hopital{
    
    /**
     * main de l'application
     * @param args
     * @throws IOException
     * @throws java.net.URISyntaxException
     */
    
    public static void main(String[] args) throws IOException, URISyntaxException {
     fentreCard fentreCard = new fentreCard();
     Presentation presentation = new Presentation("Presentation");
 
    }
}

